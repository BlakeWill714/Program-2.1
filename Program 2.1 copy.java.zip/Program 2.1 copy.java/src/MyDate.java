import java.util.Calendar;
import java.util.GregorianCalendar;

public class MyDate {
    private int year;
    private int month;  // 0-based (0 for January)
    private int day;

    public MyDate() {
        // Get the current date and time
        GregorianCalendar cal = new GregorianCalendar();
        this.year = cal.get(Calendar.YEAR);
        this.month = cal.get(Calendar.MONTH);
        this.day = cal.get(Calendar.DAY_OF_MONTH);
    }

    public MyDate(long elapsedTime) {
        // Construct a MyDate object based on elapsed time
        setDate(elapsedTime);
    }

    public MyDate(int year, int month, int day) {
        this.year = year;
        this.month = month;
        this.day = day;
    }

    public int getYear() {
        return year;
    }

    public int getMonth() {
        return month;
    }

    public int getDay() {
        return day;
    }

    public void setDate(long elapsedTime) {
        // Set a new date based on elapsed time
        GregorianCalendar cal = new GregorianCalendar();
        cal.setTimeInMillis(elapsedTime);
        this.year = cal.get(Calendar.YEAR);
        this.month = cal.get(Calendar.MONTH);
        this.day = cal.get(Calendar.DAY_OF_MONTH);
    }

    public static void main(String[] args) {
        MyDate date1 = new MyDate(); // Current date
        MyDate date2 = new MyDate(34355555133101L);

        // Display the year, month, and day for both MyDate objects
        System.out.println("Current Date: Year " + date1.getYear() + ", Month " + date1.getMonth() + ", Day " + date1.getDay());
        System.out.println("Custom Date: Year " + date2.getYear() + ", Month " + date2.getMonth() + ", Day " + date2.getDay());
    }
}
// -------------------------------------
//|          MyDate                   |
//-------------------------------------
//| - year: int                        |
//| - month: int (0-based)            |
//| - day: int                         |
//-------------------------------------
//| + MyDate()                        |
//| + MyDate(elapsedTime: long)       |
//| + MyDate(year: int, month: int, day: int) |
//| + getYear(): int                   |
//| + getMonth(): int (0-based)        |
//| + getDay(): int                    |
//| + setDate(elapsedTime: long): void |
//-------------------------------------